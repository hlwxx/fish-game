

main.js                 主程序
commonFunction.js       公共程序
background.js           背景
ane.js                  海葵
fruit.js                果实

黄色果实和蓝色果实  长大=》在熟
